<?php
/*
 * Version definition file.
 *
 * - $LastChangedDate$
 * - $Rev$
 */

$revision = '$Format:%H$';
$revision = str_replace('$', '', str_replace(' ', '', str_replace('Rev: ', '', $revision)));
$version = '9.0.0.1'.' - r'.$revision.'@github';
?><?php $version = '9.0.0.1'; ?>