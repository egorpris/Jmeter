<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Untitled Document</title>
</head>

<body topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><div align="center">
     
      <form action="email_password_sender.php" method="post" name="form" id="form">
      
        <div align="center"><strong><font size="3">
          <font face="Verdana, Arial, Helvetica, sans-serif">
          <legend><font size="4"><br>
          <br>
          Reset Password Via Email </font><font size="2"><br>
          <br>
          <br />
          </font></legend>
          </font></font></strong>
            <div style="text-align:left; width:400px; height:20px; margin-top:10px;">
              <div style=" float:left; text-align:right; width:200px; border:1px; padding-right:10px;"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Email Address Associated with this account </font></strong></div>
              <div style="float:left; text-align:left; border: 1px; width:140px; ">
                <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                <input type="text" name="email" value = '' />
              </font></div>
            </div>
            <p class="submit"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>
              <input name="submit" type="submit" value="Submit" />
            </strong></font></p>
            <p class="submit"><a href="login.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">I remember now. Back to Login </font></a></p>
            <p class="submit"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="email_password.php"></a></font></p>
            <p class="submit">&nbsp;</p>
            <p class="submit">&nbsp;</p>
            <p class="submit"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="agent_add_form.php"></a></font></p>
          <strong><font size="3">
            <legend><br />
            </legend>
          </font></strong></div>
         
      </form>
      <p align="left"><br>
      </p>
    </div></td>
  </tr>
</table>
<br>
<A href="http://www.amsmerchant.com" target="_blank"></A><br>
<br>
</body>
</html>
