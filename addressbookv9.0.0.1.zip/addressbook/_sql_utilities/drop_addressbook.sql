DROP TABLE IF EXISTS addressbook       ;
DROP TABLE IF EXISTS group_list        ;
DROP TABLE IF EXISTS address_in_groups ;
DROP TABLE IF EXISTS user_prefs        ;
DROP TABLE IF EXISTS month_lookup      ;
DROP VIEW  IF EXISTS vw_address        ;
DROP VIEW  IF EXISTS vw_address_deleted;

